var textToDo=document.querySelector("input");
var todolist=document.querySelector("ul");
var remove=document.querySelector(".removeBtn");

document.querySelector("input").addEventListener("keypress",function(event){
    if(event.keyCode === 13)
    {
        var newli=document.createElement("li");
        
        newli.addEventListener("click",function(event){
            this.classList.toggle('TextLineThrough');
        });
        
        var newtext=document.createTextNode(textToDo.value);
        var removeBtn=document.createElement("button");
        var btnName=document.createTextNode("X");
        removeBtn.setAttribute("class","removeBtn");
        
        removeBtn.setAttribute("tabIndex","-1");
        removeBtn.addEventListener("click",function (event){
            this.parentElement.style.display="none";
        });
        
        
        removeBtn.appendChild(btnName);
        newli.appendChild(removeBtn);
        newli.appendChild(newtext);
        todolist.appendChild(newli);
        textToDo.value="";                
    }
    
});

remove.setAttribute("tabIndex","-1");
remove.addEventListener("click",function (){
            this.parentElement.style.display="none";
        });
function addTodo(){
    var add=prompt("Add To Do List","To Do List");
    if(add!==null && add!=="")
    {
        document.getElementById("head_part").innerHTML=add;
    }    
}

function removeMe(v) {
    v.parentElement.style.display="none";
}